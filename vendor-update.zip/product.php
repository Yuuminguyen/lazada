<?php
session_start();

function read_from_file() {
  $file_name = 'newproduct.csv';
  $fp = fopen($file_name, 'r');
  // first row => field names
  $first = fgetcsv($fp);
  $newproduct = [];
  while ($row = fgetcsv($fp)) {
    $i = 0;
    $product = [];
    foreach ($first as $col_name) {
      $product[$col_name] =  $row[$i];
      // treat sizes differently
      // make it an array
      if ($col_name == 'sizes') {
        $product[$col_name] = explode(',', $product[$col_name]);
      }
      $i++;
    }
    $newproduct[] = $product;
  }
  // overwrite the session variable
  $_SESSION['newproduct'] = $newproduct;
}


if (isset($_SESSION['newproduct'])) {
  echo '<pre>';
  print_r($_SESSION['newproduct']);
  echo '</pre>';
}
