<?php
  session_start();

  
  if (isset($_POST['act'])) {
    $product = [
      'name' => $_POST['product_name'],
      'price' => $_POST['price'],
      'sizes' => $_POST['sizes'],
      'created_time' => date('Y-m-d h:i:s')
    ];
    $_SESSION['products'][] = $product;
  }
?>

<form method="post" action="addproduct.php">
  Product name <input type="text" name="productname"><br>
  Price <input type="number" name="price"><br>
  Image <type="file" name="file"><br>
  Description <input type="text" name="discription"><br>
  <input type="submit" name="act" value="Add">
</form>

<?php

  if (isset($_SESSION['product'])) {
    echo '<pre>';
    print_r($_SESSION['product']);
    echo '</pre>';
  }
?>