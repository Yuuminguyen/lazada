<?php
echo "<h1>Thankyou for doing this signup and login procees</h1>";
?>