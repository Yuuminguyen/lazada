Steps are given to run the project in your System
#1. Download the folder by pressing clone or download button.
#2. Place the folder in htdocs or WWW folder in XAMPP or WAMP respectively.
#3. Configure the function mysqli_connect in login.php by given your software username password and database.
#4. Make database by watching my video.
#5. Last run the project and enjoy it
#6. Thanks for your support.
