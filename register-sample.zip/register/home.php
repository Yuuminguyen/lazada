<?php 
	session_start();
	if(!isset($_SESSION['user'])){
		header("location: login.php");	exit();
	}

	if(isset($_GET['logout'])){
		unset($_SESSION['user']);
		header("location: login.php");	exit();
	}

 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- font awesome cdn link  -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
    />

    <!-- custom css file link  -->
    <!-- <link rel="stylesheet" href="css/style.css" /> -->
  </head>
  <body>
    <!-- header section starts  -->

    <header>
      <input type="checkbox" name="" id="toggler" />
      <label for="toggler" class="fas fa-bars"></label>

      <a href="#" class="logo">LAZADA</a>

      <nav class="navbar">
        <a href="#home">Home</a>
        <a href="#products">Flashsale</a>
        <a href="#contact">Lazchat</a>
      </nav>

      <div class="icons">
        <a href="#" class="fa-solid fa-heart"></a>
        <a href="#" class="fa-solid fa-cart-shopping"><span>0</span></a>
        <a href="#" class="fa-solid fa-user"></a>
        <a href="./index.php">Log out</a>
      </div>
    </header>

    <section class="home" id="home">
      <div class="content">
        <h3>LAZADA 9.9</h3>
        <span> Sale 50% </span>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae
          laborum ut minus corrupti dolorum dolore assumenda iste voluptate
          dolorem pariatur.
        </p>
      </div>
    </section>

    <section class="icons-container">
      <div class="icons">
        <img src="images/icon-1.png" alt="" />
        <div class="info">
          <h3>Freeship Max</h3>
          <span>on all orders</span>
        </div>
      </div>

      <div class="icons">
        <img src="images/icon-1.png" alt="" />
        <div class="info">
          <h3>free delivery</h3>
          <span>on all orders</span>
        </div>
      </div>

      <div class="icons">
        <img src="images/icon-2.png" alt="" />
        <div class="info">
          <h3>10 days returns</h3>
          <span>moneyback guarantee</span>
        </div>
      </div>

      <div class="icons">
        <img src="images/icon-3.png" alt="" />
        <div class="info">
          <h3>offer & gifts</h3>
          <span>on all orders</span>
        </div>
      </div>

      <div class="icons">
        <img src="images/icon-4.png" alt="" />
        <div class="info">
          <h3>secure paymens</h3>
          <span>protected by paypal</span>
        </div>
      </div>
    </section>

    <section class="products" id="products">
      <h1 class="heading">Flash<span>Sale</span></h1>

      <div class="box-container">
        <div class="box">
          <span class="discount">-10%</span>
          <div class="image">
            <img src="images/img-1.jpg" alt="" />
            <div class="icons">
              <a href="#" class="fa-solid fa-heart"></a>
              <a href="#" class="cart-btn">add to cart</a>
              <a href="#" class="fa-solid fa-share"></a>
            </div>
          </div>
          <div class="content">
            <h3>flower pot</h3>
            <div class="price">$12.99 <span>$15.99</span></div>
          </div>
        </div>

        <div class="box">
          <span class="discount">-15%</span>
          <div class="image">
            <img src="images/img-2.jpg" alt="" />
            <div class="icons">
              <a href="#" class="fa-solid fa-heart"></a>
              <a href="#" class="cart-btn">add to cart</a>
              <a href="#" class="fa-solid fa-share"></a>
            </div>
          </div>
          <div class="content">
            <h3>flower pot</h3>
            <div class="price">$12.99 <span>$15.99</span></div>
          </div>
        </div>

        <div class="box">
          <span class="discount">-5%</span>
          <div class="image">
            <img src="images/img-3.jpg" alt="" />
            <div class="icons">
              <a href="#" class="fa-solid fa-heart"></a>
              <a href="#" class="cart-btn">add to cart</a>
              <a href="#" class="fa-solid fa-share"></a>
            </div>
          </div>
          <div class="content">
            <h3>flower pot</h3>
            <div class="price">$12.99 <span>$15.99</span></div>
          </div>
        </div>

        <div class="box">
          <span class="discount">-20%</span>
          <div class="image">
            <img src="images/img-4.jpg" alt="" />
            <div class="icons">
              <a href="#" class="fa-solid fa-heart"></a>
              <a href="#" class="cart-btn">add to cart</a>
              <a href="#" class="fa-solid fa-share"></a>
            </div>
          </div>
          <div class="content">
            <h3>flower pot</h3>
            <div class="price">$12.99 <span>$15.99</span></div>
          </div>
        </div>

        <div class="box">
          <span class="discount">-17%</span>
          <div class="image">
            <img src="images/img-5.jpg" alt="" />
            <div class="icons">
              <a href="#" class="fa-solid fa-heart"></a>
              <a href="#" class="cart-btn">add to cart</a>
              <a href="#" class="fa-solid fa-share"></a>
            </div>
          </div>
          <div class="content">
            <h3>flower pot</h3>
            <div class="price">$12.99 <span>$15.99</span></div>
          </div>
        </div>

        <div class="box">
          <span class="discount">-3%</span>
          <div class="image">
            <img src="images/img-6.jpg" alt="" />
            <div class="icons">
              <a href="#" class="fa-solid fa-heart"></a>
              <a href="#" class="cart-btn">add to cart</a>
              <a href="#" class="fa-solid fa-share"></a>
            </div>
          </div>
          <div class="content">
            <h3>flower pot</h3>
            <div class="price">$12.99 <span>$15.99</span></div>
          </div>
        </div>

        <div class="box">
          <span class="discount">-18%</span>
          <div class="image">
            <img src="images/img-7.jpg" alt="" />
            <div class="icons">
              <a href="#" class="fa-solid fa-heart"></a>
              <a href="#" class="cart-btn">add to cart</a>
              <a href="#" class="fa-solid fa-share"></a>
            </div>
          </div>
          <div class="content">
            <h3>flower pot</h3>
            <div class="price">$12.99 <span>$15.99</span></div>
          </div>
        </div>

        <div class="box">
          <span class="discount">-10%</span>
          <div class="image">
            <img src="images/img-8.jpg" alt="" />
            <div class="icons">
              <a href="#" class="fa-solid fa-heart"></a>
              <a href="#" class="cart-btn">add to cart</a>
              <a href="#" class="fa-solid fa-share"></a>
            </div>
          </div>
          <div class="content">
            <h3>flower pot</h3>
            <div class="price">$12.99 <span>$15.99</span></div>
          </div>
        </div>

        <div class="box">
          <span class="discount">-5%</span>
          <div class="image">
            <img src="images/img-9.jpg" alt="" />
            <div class="icons">
              <a href="#" class="fa-solid fa-heart"></a>
              <a href="#" class="cart-btn">add to cart</a>
              <a href="#" class="fa-solid fa-share"></a>
            </div>
          </div>
          <div class="content">
            <h3>flower pot</h3>
            <div class="price">$12.99 <span>$15.99</span></div>
          </div>
        </div>
      </div>
    </section>

    <!-- prodcuts section ends -->

    <!-- review section starts  -->

    <!-- review section ends -->

    <!-- contact section starts  -->

    <section class="contact" id="contact">
      <h1 class="heading">Lazchat</h1>

      <div class="row">
        <form action="">
          <input type="text" placeholder="name" class="box" />
          <input type="email" placeholder="email" class="box" />
          <input type="number" placeholder="number" class="box" />
          <textarea
            name=""
            class="box"
            placeholder="message"
            id=""
            cols="30"
            rows="10"
          ></textarea>
          <input type="submit" value="send message" class="btn" />
        </form>

        <div class="image">
          <img src="images/contact-img.svg" alt="" />
        </div>
      </div>
    </section>

    <!-- contact section ends -->

    <!-- footer section starts  -->

    <section class="footer">
      <div class="box-container">
        <div class="box">
          <h3>quick links</h3>
          <a href="#">home</a>
          <a href="#">about</a>
          <a href="#">products</a>
          <a href="#">review</a>
          <a href="#">contact</a>
        </div>

        <div class="box">
          <h3>extra links</h3>
          <a href="#">my account</a>
          <a href="#">my order</a>
          <a href="#">my favorite</a>
        </div>

        <div class="box">
          <h3>locations</h3>
          <a href="#">india</a>
          <a href="#">USA</a>
          <a href="#">japan</a>
          <a href="#">france</a>
        </div>

        <div class="box">
          <h3>contact info</h3>
          <a href="#">+123-456-7890</a>
          <a href="#">example@gmail.com</a>
          <a href="#">mumbai, india - 400104</a>
          <img src="images/payment.png" alt="" />
        </div>
      </div>

      <div class="credit">
        Created by <span> Group 21 & Lazada </span> | all rights reserved
      </div>
    </section>

    <!-- footer section ends -->

    <script src="./js/cart.js"></script>
  </body>
</html>
