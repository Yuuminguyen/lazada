<?php 

class RegisterUser{
	// Class properties
	private $username;
	private $raw_password;
	private $encrypted_password;
	private $raw_email;
	private $encrypted_email;
	private $encrypted_address;
	private $raw_address;
	public $error;
	public $success;
	private $storage = "file.json";
	private $stored_users;
	private $new_user; // array 

	public function __construct($username, $password, $email, $address){

		$this->username = trim($this->username);
		$this->username = filter_var($username);

		$this->raw_password = filter_var(trim($password));
		$this->encrypted_password = password_hash($this->raw_password, PASSWORD_DEFAULT);

		$this->encrypted_address = password_hash($this->raw_address, PASSWORD_DEFAULT);
		$this->raw_address = filter_var(trim($address));

		$this->raw_email = filter_var(trim($email));
		$this->encrypted_email = password_hash($this->raw_email, PASSWORD_DEFAULT);


		$this->stored_users = json_decode(file_get_contents($this->storage), true);

		$this->new_user = [
			"username" => $this->username,
			"password" => $this->encrypted_password,
			"email" => $this->encrypted_email,
			"address" => $this->encrypted_address,
		];

		if($this->checkFieldValues()){
			$this->insertUser();
		}
	}


	private function checkFieldValues(){
		if(empty($this->username) || empty($this->raw_password)){
			if(empty($this->username) || empty($this->raw_address)){
				$this->error = "Both fields are required.";
				return false;
			}
		}else{
			return true;
		}
	}

	private function usernameExists(){
		if (is_array($this->stored_users) || is_object($this->stored_users)){
		foreach($this->stored_users as $user){
			if($this->username == $user['username']){
				$this->error = "Username already taken, please choose a different one.";
				return true;
			}
		}}
		return false;
	}


	private function insertUser(){
		if($this->usernameExists() == FALSE){
			$this->stored_users[]=$this->new_user;
			if(file_put_contents($this->storage, json_encode($this->stored_users, JSON_PRETTY_PRINT))){
				return $this->success = "Your registration was successful";
			}else{
				return $this->error = "Something went wrong, please try again";
			}
		}
	}



} // end of class