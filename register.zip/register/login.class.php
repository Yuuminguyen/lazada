<?php 
class LoginUser{
	// class properties
	private $username;
	private $password;
	public $error;
	public $success;
	private $storage = "file.json";
	private $stored_users;

	// class methods
	public function __construct($username, $password){
		$this->username = $username;
		$this->password = $password;
		$this->stored_users = json_decode(file_get_contents($this->storage), true);
		$this->login();
	}


	private function login(){
        if(is_array($this->stored_users)||is_object($this->stored_users)){
            foreach ($this->stored_users as $user) {
                if($user['username'] == $this->username){
                    if(password_verify($this->password, $user['password'])){
                        session_start();
                        $_SESSION['user'] = $this->username;
                        header("location: home.php"); exit();
                    }
                }
            }
            return $this->error = "Wrong username or password";
        }
		
	}

}