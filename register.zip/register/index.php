
<?php require("register.class.php") ?>
<?php 
	if(isset($_POST['submit'])){
		$user = new RegisterUser($_POST['username'], $_POST['password']);
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="/lazada_update/css/style.css"> -->
    <!-- <link rel="stylesheet" href="./roles.css"> -->
    <!-- <link rel="stylesheet" href="index.html"> -->
    <script src="https://kit.fontawesome.com/f6af0088ad.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <div class="forms-container">
            <div class="signin-signout">
                <form action="" method="post" enctype="multipart/form-data" autocomplete="off" id="form">
                    <h2 class="title">Sign up</h2>
                    <p>To be our pleasure</p>
                    <div class="input-field">
                        <i class="fas fa-user"></i>
                        <input type="text" placeholder="Username" id="username" name="username">
                        <small>Error message</small>
                    </div>
                    <!-- <div class="input-field">
                        <i class="fas fa-user"></i>
                        <input type="text" placeholder="Email" id="email">
                        <small>Error message</small>
                    </div> -->
                    <div class="input-field">
                        <i class="fas fa-user"></i>
                        <input type="password" placeholder="Password" id="password" name="password">
                        <small>Error message</small>
                    </div>
                    <!-- <div class="input-field">
                        <i class="fas fa-user"></i>
                        <input type="text" placeholder="address" id="address">
                        <small>Error message</small>
                    </div> -->
                    <button type="submit" name="submit">Register</button>

                    <p class="error"><?php echo @$user->error ?></p>
		            <p class="success"><?php echo @$user->success ?></p>
                </form>
            </div>
        </div>
    </div>
    <style>
.input-field.success input {
    border-color: #2ecc71;
}

.input-field.error input {
    border-color: #e74c3c;
}

.input-field.error small {
    color: #e74c3c;
    visibility: visible;
}

.input-field input{
    border: 2px solid #f0f0f0;
    font-size: 14px;
    width: 100%;
    background-color: #f0f0f0;
    border-radius: 55px;
    padding: 0 .4rem;
}

.input-field small{
    visibility: hidden;
    position: absolute;
    bottom: 0;
    left: 0;
}

button {
    background-color: #8e44ad;
    border: 2px solid #8e44ad;
    border-radius: 4px;
    color: #fff;
    display: block;
    font-size: 16px;
    padding: 10px;
    width: 50%;
}

select {   
    border: none;
    outline: none;
    border-radius: 49px;
    cursor: pointer;
    text-align: center;
    line-height: 55px;
    color: #acacac;
    font-size: 1.1rem;
    background-color: #f0f0f0;
    max-width: 380px;
    width: 100%;
    height: 55px;
    margin: 10px 0;
}

option {
    color: #333;
}
    </style>
</body>
<!-- <script src="./js/customer_login.js"></script> -->
</html>
